const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Свързване с SQLite
const db = new sqlite3.Database('./database.sqlite', (err) => {
    if (err) {
        console.error('❌ Грешка при отваряне на базата данни:', err.message);
    } else {
        console.log('✅ Успешно свързване с SQLite!');
        initDatabase();
    }
});

// Създаване на таблици
function initDatabase() {
    db.serialize(() => {
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            class_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            grade_level INTEGER NOT NULL
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            teacher_id INTEGER,
            FOREIGN KEY (teacher_id) REFERENCES users(id)
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS grades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject_id INTEGER NOT NULL,
            teacher_id INTEGER NOT NULL,
            grade_value REAL NOT NULL,
            type TEXT DEFAULT 'oral',
            comment TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES users(id),
            FOREIGN KEY (subject_id) REFERENCES subjects(id),
            FOREIGN KEY (teacher_id) REFERENCES users(id)
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS attendances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            date DATE NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES users(id)
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS homework (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_id INTEGER NOT NULL,
            class_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            due_date DATE NOT NULL,
            created_by INTEGER NOT NULL,
            FOREIGN KEY (subject_id) REFERENCES subjects(id),
            FOREIGN KEY (class_id) REFERENCES classes(id),
            FOREIGN KEY (created_by) REFERENCES users(id)
        )`);

        // Добавяне на примерни данни
        db.get("SELECT count(*) as count FROM users", (err, row) => {
            if (row.count === 0) {
                console.log('📝 Добавяне на примерни данни...');
                
                db.run("INSERT INTO classes (name, grade_level) VALUES ('8А', 8)");
                db.run("INSERT INTO classes (name, grade_level) VALUES ('9Б', 9)");
                db.run("INSERT INTO subjects (name) VALUES ('Математика')");
                db.run("INSERT INTO subjects (name) VALUES ('Български език')");
                db.run("INSERT INTO subjects (name) VALUES ('Английски език')");
                
                const hashedTeacher = bcrypt.hashSync('teacher123', 10);
                const hashedStudent = bcrypt.hashSync('student123', 10);
                
                db.run("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)", 
                    ['Иван Петров', 'ivan@teacher.bg', hashedTeacher, 'teacher']);
                db.run("INSERT INTO users (name, email, password, role, class_id) VALUES (?, ?, ?, ?, ?)", 
                    ['Мария Георгиева', 'maria@student.bg', hashedStudent, 'student', 1]);
                    
                console.log('✅ Примерни данни добавени!');
            }
        });
    });
}

// Middleware за токен
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) return res.status(401).json({ error: 'Достъп отказан' });
    
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: 'Невалиден токен' });
        req.user = user;
        next();
    });
};

// AUTH ROUTES
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password, role, class_id } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        
        db.run('INSERT INTO users (name, email, password, role, class_id) VALUES (?, ?, ?, ?, ?)', 
            [name, email, hashedPassword, role, class_id], 
            function(err) {
                if (err) return res.status(500).json({ error: err.message });
                res.status(201).json({ message: 'Потребителят е създаден', id: this.lastID });
            }
        );
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    
    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!user) return res.status(401).json({ error: 'Грешен имейл или парола' });
        
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) return res.status(401).json({ error: 'Грешен имейл или парола' });
        
        const token = jwt.sign(
            { id: user.id, role: user.role, name: user.name },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        res.json({ 
            token, 
            user: { id: user.id, name: user.name, email: user.email, role: user.role, class_id: user.class_id }
        });
    });
});

// USERS ROUTES
app.get('/api/users/students', authenticateToken, (req, res) => {
    db.all('SELECT id, name, email, class_id FROM users WHERE role = "student"', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// GRADES ROUTES
app.get('/api/grades', authenticateToken, (req, res) => {
    let sql = `
        SELECT g.id, g.grade_value, g.type, g.comment, g.created_at,
               s.name as subject_name, u.name as student_name
        FROM grades g
        JOIN subjects s ON g.subject_id = s.id
        JOIN users u ON g.student_id = u.id
    `;
    
    if (req.user.role === 'student') {
        sql += ' WHERE g.student_id = ?';
        db.all(sql, [req.user.id], (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        });
    } else {
        db.all(sql, (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        });
    }
});

app.post('/api/grades', authenticateToken, (req, res) => {
    if (req.user.role !== 'teacher') {
        return res.status(403).json({ error: 'Само учители могат да добавят оценки' });
    }
    
    const { student_id, subject_id, grade_value, type, comment } = req.body;
    db.run('INSERT INTO grades (student_id, subject_id, teacher_id, grade_value, type, comment) VALUES (?, ?, ?, ?, ?, ?)', 
        [student_id, subject_id, req.user.id, grade_value, type, comment], 
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Оценката е добавена', id: this.lastID });
        }
    );
});

// SUBJECTS ROUTES
app.get('/api/subjects', authenticateToken, (req, res) => {
    db.all('SELECT * FROM subjects', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// CLASSES ROUTES
app.get('/api/classes', authenticateToken, (req, res) => {
    db.all('SELECT * FROM classes', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// ATTENDANCE ROUTES
app.get('/api/attendance', authenticateToken, (req, res) => {
    let sql = `
        SELECT a.id, a.date, a.status, u.name as student_name
        FROM attendances a
        JOIN users u ON a.student_id = u.id
    `;
    
    if (req.user.role === 'student') {
        sql += ' WHERE a.student_id = ?';
        db.all(sql, [req.user.id], (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        });
    } else {
        db.all(sql, (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        });
    }
});

app.post('/api/attendance', authenticateToken, (req, res) => {
    if (req.user.role !== 'teacher') {
        return res.status(403).json({ error: 'Само учители могат' });
    }
    
    const { student_id, date, status } = req.body;
    db.run('INSERT INTO attendances (student_id, date, status) VALUES (?, ?, ?)', 
        [student_id, date, status], 
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Присъствието е отбелязано', id: this.lastID });
        }
    );
});

// HOMEWORK ROUTES
app.get('/api/homework', authenticateToken, (req, res) => {
    let sql = `
        SELECT h.id, h.description, h.due_date, s.name as subject_name, c.name as class_name
        FROM homework h
        JOIN subjects s ON h.subject_id = s.id
        JOIN classes c ON h.class_id = c.id
    `;
    
    db.all(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/homework', authenticateToken, (req, res) => {
    if (req.user.role !== 'teacher') {
        return res.status(403).json({ error: 'Само учители могат' });
    }
    
    const { subject_id, class_id, description, due_date } = req.body;
    db.run('INSERT INTO homework (subject_id, class_id, description, due_date, created_by) VALUES (?, ?, ?, ?, ?)', 
        [subject_id, class_id, description, due_date, req.user.id], 
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Домашното е добавено', id: this.lastID });
        }
    );
});

// START SERVER
app.listen(PORT, () => {
    console.log(`🚀 Сървърът работи на http://localhost:${PORT}`);
});